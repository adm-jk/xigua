# frozen_string_literal: true

module RQRCode
  VERSION = "1.0.0"
end
